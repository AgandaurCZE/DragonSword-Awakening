DragonSword: Awakening — Assets

Extracted from DragonSword_Visual_Tier_List_Data.json.

Folders:
- heroes/: character portraits
- archetypes/: one PNG per unique archetype icon (deduplicated)
- roles/: Main DPS, Sub-DPS, Support icons
- gear_sets/: 12 gear-set icons
- gear_slots/: five equipment-slot icons

The current HTML and JSON already contain embedded image data, so these files are optional for opening the current offline tier list. Keep these PNGs if you want to edit, replace, or reuse the images individually.
